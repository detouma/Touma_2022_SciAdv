Datasets with the annual frequency of extreme precipitation (99.9th percentile) for
all large ensemble experiments listed in Table S1.

Used to make main figures
Fig. 1D-F
Fig. 2
Fig. 3B

Used to make supplemental figures
Fig. S2B
Fig. S3
Fig. S4
