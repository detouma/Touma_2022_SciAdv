These files show the date of an R99.9 event occurring after an FWI99.9 event, and are used to make Fig. 6B,D,F
