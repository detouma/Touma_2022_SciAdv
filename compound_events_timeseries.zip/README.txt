This dataset contains the annual frequency of compound events for each state.
It is used to make:
Fig. 3C-F
Fig. 7C,F,I
