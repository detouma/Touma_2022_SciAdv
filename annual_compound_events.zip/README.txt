These datasets are used to calculate the frequency and fraction of FWI99.9 events followed by R99.9 events.

They can be used to create:
Fig. 4
Fig. 5
Fig. 7A,B,D,E,G,H

and supplementary figures:
Fig. S5
Fig. S6
Fig. S7
Fig. S8

